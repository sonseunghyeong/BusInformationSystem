﻿using System.Drawing;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Image image = new Image();
            image.Source = new BitmapImage(new Uri("C:\\Users\\Administrator\\source\\repos\\WpfApp2\\WpfApp2/main_bk.png"));

 //           Bitmap b = new Bitmap(200, 100);                                  // 비트맵 생성
//            Graphics g = Graphics.FromImage(b);                               // 그래팩 클래스 생성 (이미지로부터)
 //           g.Clear(Color.Gray);                                              // 그래픽을 회색색칠하기
//            Brush blackBrush = new SolidBrush(Color.Black);                   // FontColor
//            FontFamily familyName = new FontFamily("굴림");                   // FontFamily
//            System.Drawing.Font myFont = new System.Drawing.Font(familyName, 20, FontStyle.Regular, GraphicsUnit.Pixel);                                                        // 폰트생성
//            PointF startPoint = new PointF(10, 20);                           // 글자 시작위치
//            g.DrawString("Hello World!", myFont, blackBrush, startPoint);     // 글자 쓰기
//            b.MakeTransparent(Color.Gray);                                    // 회색을 투명색으로 지정
//            g.DrawImage(b, new Point(10, 10));
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}